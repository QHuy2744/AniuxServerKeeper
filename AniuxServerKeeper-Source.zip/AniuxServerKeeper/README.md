# Aniux Server Keeper

Ứng dụng Android trợ giúp vận hành server Minecraft chạy trên cùng điện thoại.

## Có gì trong bản 1.0

- Chọn một ứng dụng server trong danh sách ứng dụng có biểu tượng.
- Mở ứng dụng server đã chọn.
- Bật/tắt foreground service có thông báo thường trực.
- Khi được bật, dịch vụ giữ CPU thức bằng `PARTIAL_WAKE_LOCK` để giảm tình trạng CPU ngủ khi tắt màn hình.
- Mở trang cài đặt ứng dụng server và danh sách tối ưu pin của Android.
- Giao diện nền tối, xanh neon.

## Giới hạn quan trọng

Tool **không thể bảo đảm** giữ một APK khác chạy mãi, cũng không thể tự khởi động lại server nếu APK server tự dừng, bị buộc dừng, bị hệ thống dọn bộ nhớ hoặc cần một dịch vụ nền riêng của chính nó. Foreground service và wake lock chỉ cải thiện khả năng tiếp tục hoạt động khi CPU ngủ; Android/HyperOS vẫn có quyền quản lý tiến trình. Muốn xử lý đúng nguyên nhân cần biết tên ứng dụng server cụ thể và cách nó chạy server.

Chế độ giữ CPU thức có thể làm hao pin/nóng máy. Hãy chỉ bật khi thật sự cần, ưu tiên cắm sạc nơi thông thoáng và nhấn Dừng khi server không chạy. Không coi trạng thái của tool là bằng chứng rằng server Minecraft đang online.

## Tự build APK bằng GitHub Actions

Project có sẵn workflow `.github/workflows/build-apk.yml`. Khi source được đưa lên một GitHub repository và push lên nhánh `main` hoặc `master`, workflow sẽ build APK debug. Có thể chạy thủ công bằng tab **Actions** → **Build Aniux Server Keeper APK** → **Run workflow**.

Sau khi build hoàn tất:

1. Mở lần chạy workflow vừa thành công.
2. Kéo xuống mục **Artifacts**.
3. Tải `Aniux-Server-Keeper-debug-APK` về điện thoại và giải nén.
4. Mở `app-debug.apk` để cài. Android có thể yêu cầu cho phép cài ứng dụng từ nguồn này.

Đây là APK debug để thử nghiệm, chưa phải bản phát hành đã ký bằng khóa riêng.

## Thiết lập trên Redmi/HyperOS

1. Mở Aniux Server Keeper và chọn ứng dụng server trong danh sách.
2. Bấm **Cài đặt pin của app server**; tại trang thông tin ứng dụng, tìm mục Pin/tiết kiệm pin và chọn **Không hạn chế** nếu có.
3. Nếu máy có mục **Tự khởi động nền**, bật cho ứng dụng server.
4. Mở server, quay lại tool và bật **Giữ CPU thức**.
5. Khóa ứng dụng server trong màn hình gần đây nếu HyperOS có tùy chọn đó.
6. Kiểm tra server bằng một thiết bị khác. Nếu vẫn tự tắt, cần tích hợp theo đúng ứng dụng server đang dùng; tool tổng quát không thể khắc phục mọi giới hạn của HyperOS.

## Build configuration

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Compile/target SDK: 35
- Minimum SDK: 26 (Android 8.0)
- Java: 17
