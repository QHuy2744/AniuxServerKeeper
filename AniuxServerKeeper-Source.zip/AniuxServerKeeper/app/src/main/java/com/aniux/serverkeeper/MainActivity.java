package com.aniux.serverkeeper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "aniux_server_keeper";
    private static final String KEY_PACKAGE = "server_package";
    private static final String KEY_ACTIVE = "keeper_enabled";

    private final int bg = Color.rgb(8, 13, 24);
    private final int card = Color.rgb(17, 27, 45);
    private final int card2 = Color.rgb(22, 37, 59);
    private final int blue = Color.rgb(53, 184, 255);
    private final int green = Color.rgb(64, 220, 155);
    private final int white = Color.rgb(240, 247, 255);
    private final int muted = Color.rgb(157, 177, 203);

    private Spinner appSpinner;
    private TextView stateTitle;
    private TextView stateDetails;
    private TextView selectedAppText;
    private Button keeperButton;
    private final List<AppEntry> apps = new ArrayList<>();
    private String selectedPackage = "";

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);
        selectedPackage = prefs().getString(KEY_PACKAGE, "");
        buildScreen();
        loadApps();
        requestNotificationPermissionIfNeeded();
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stateTitle != null) refreshStatus();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 301);
        }
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(18), dp(20), dp(30));
        scroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView overline = text("ANDROID  •  MINECRAFT SERVER", 11, blue, true);
        overline.setLetterSpacing(0.09f);
        page.addView(overline, lpWrap(0, 0, 0, 9));

        TextView title = text("ANIUX SERVER\nKEEPER", 30, white, true);
        title.setLineSpacing(dp(1), 1.0f);
        page.addView(title, lpWrap(0, 0, 0, 7));

        TextView subtitle = text("Trợ lý giữ server chạy nền trên Android", 14, muted, false);
        page.addView(subtitle, lpWrap(0, 0, 0, 20));

        LinearLayout statusCard = cardLayout(card, 18);
        statusCard.setBackground(roundRect(card, 18, 1, Color.rgb(35, 67, 97)));
        page.addView(statusCard, lpMatch(0, 0, 0, 16));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusCard.addView(statusRow, lpMatch(0, 0, 0, 10));

        TextView dot = text("●", 16, green, true);
        statusRow.addView(dot, lpWrap(0, 0, 10, 0));
        stateTitle = text("CHƯA BẬT CHẾ ĐỘ GIỮ NỀN", 14, white, true);
        statusRow.addView(stateTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        stateDetails = text("Bật chế độ này khi server đang chạy. CPU sẽ được giữ thức trong lúc chế độ hoạt động.", 13, muted, false);
        stateDetails.setLineSpacing(dp(4), 1.0f);
        statusCard.addView(stateDetails, lpMatch(0, 0, 0, 0));

        TextView appLabel = text("1. CHỌN ỨNG DỤNG SERVER", 13, white, true);
        page.addView(appLabel, lpWrap(2, 0, 0, 8));

        LinearLayout appCard = cardLayout(card2, 14);
        page.addView(appCard, lpMatch(0, 0, 0, 6));
        appSpinner = new Spinner(this);
        appSpinner.setPadding(dp(5), dp(8), dp(5), dp(8));
        appCard.addView(appSpinner, lpMatch(0, 0, 0, 0));

        selectedAppText = text("Chưa chọn ứng dụng server.", 12, muted, false);
        page.addView(selectedAppText, lpWrap(3, 0, 0, 17));

        TextView actionLabel = text("2. ĐIỀU KHIỂN", 13, white, true);
        page.addView(actionLabel, lpWrap(2, 0, 0, 9));

        Button openButton = button("MỞ ỨNG DỤNG SERVER", blue, bg);
        page.addView(openButton, lpMatch(0, 0, 0, 10));
        openButton.setOnClickListener(v -> openSelectedServer());

        keeperButton = button("BẬT CHẾ ĐỘ GIỮ CPU THỨC", green, bg);
        page.addView(keeperButton, lpMatch(0, 0, 0, 10));
        keeperButton.setOnClickListener(v -> toggleKeeper());

        Button appSettingsButton = button("CÀI ĐẶT PIN CỦA APP SERVER", card2, white);
        appSettingsButton.setBackground(roundRect(card2, 14, 1, Color.rgb(50, 74, 105)));
        page.addView(appSettingsButton, lpMatch(0, 0, 0, 10));
        appSettingsButton.setOnClickListener(v -> openSelectedAppSettings());

        Button batteryButton = button("CÀI ĐẶT TỐI ƯU PIN CỦA TOOL", card2, white);
        batteryButton.setBackground(roundRect(card2, 14, 1, Color.rgb(50, 74, 105)));
        page.addView(batteryButton, lpMatch(0, 0, 0, 18));
        batteryButton.setOnClickListener(v -> openBatteryOptimizationSettings());

        LinearLayout guideCard = cardLayout(card, 16);
        guideCard.setBackground(roundRect(card, 16, 1, Color.rgb(35, 67, 97)));
        page.addView(guideCard, lpMatch(0, 0, 0, 14));
        TextView guideTitle = text("CÀI ĐẶT HYPEROS", 13, blue, true);
        guideCard.addView(guideTitle, lpWrap(0, 0, 0, 8));
        TextView guideBody = text(
                "• Với app server: đặt Pin thành Không hạn chế nếu có.\n" +
                "• Bật Tự khởi động nền nếu máy có tùy chọn này.\n" +
                "• Khóa app server trong màn hình đa nhiệm nếu có biểu tượng khóa.\n" +
                "• Nên cắm sạc khi chạy server lâu; chế độ giữ CPU thức có thể hao pin.",
                13, muted, false);
        guideBody.setLineSpacing(dp(5), 1f);
        guideCard.addView(guideBody, lpMatch(0, 0, 0, 0));

        TextView limitation = text(
                "LƯU Ý: Tool này giữ CPU thức và mở được app server. Nó không thể ép Android giữ sống một APK khác nếu APK đó tự dừng hoặc hệ thống buộc dừng tiến trình.",
                12, muted, false);
        limitation.setLineSpacing(dp(4), 1f);
        page.addView(limitation, lpWrap(2, 0, 0, 0));

        setContentView(scroll);
    }

    private void loadApps() {
        apps.clear();
        apps.add(new AppEntry("-- Chọn app server Minecraft --", ""));
        Intent launcherIntent = new Intent(Intent.ACTION_MAIN);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> results = getPackageManager().queryIntentActivities(launcherIntent, 0);
        Set<String> seen = new HashSet<>();
        for (ResolveInfo info : results) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName == null || packageName.equals(getPackageName()) || !seen.add(packageName)) continue;
            String label;
            try {
                label = String.valueOf(info.loadLabel(getPackageManager()));
            } catch (Exception ex) {
                label = packageName;
            }
            apps.add(new AppEntry(label, packageName));
        }
        if (apps.size() > 1) {
            List<AppEntry> sorted = new ArrayList<>(apps.subList(1, apps.size()));
            Collections.sort(sorted, Comparator.comparing((AppEntry a) -> a.label.toLowerCase()));
            apps.subList(1, apps.size()).clear();
            apps.addAll(sorted);
        }

        List<String> names = new ArrayList<>();
        int selectedIndex = 0;
        for (int i = 0; i < apps.size(); i++) {
            AppEntry entry = apps.get(i);
            names.add(entry.label);
            if (!selectedPackage.isEmpty() && selectedPackage.equals(entry.packageName)) selectedIndex = i;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(white);
                view.setTextSize(14);
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(white);
                view.setTextSize(14);
                view.setBackgroundColor(card2);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        appSpinner.setAdapter(adapter);
        appSpinner.setSelection(selectedIndex, false);
        updateSelectedAppText();
        appSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectedPackage = apps.get(position).packageName;
                prefs().edit().putString(KEY_PACKAGE, selectedPackage).apply();
                updateSelectedAppText();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    private void updateSelectedAppText() {
        if (selectedAppText == null) return;
        AppEntry found = null;
        for (AppEntry entry : apps) {
            if (!selectedPackage.isEmpty() && selectedPackage.equals(entry.packageName)) {
                found = entry;
                break;
            }
        }
        if (found == null) selectedAppText.setText("Chưa chọn ứng dụng server. Tool có thể mở các app có biểu tượng trên máy.");
        else selectedAppText.setText("Đã chọn: " + found.label + "\n" + found.packageName);
    }

    private void openSelectedServer() {
        if (selectedPackage.isEmpty()) {
            toast("Bạn hãy chọn APK server trước nhé.");
            return;
        }
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(selectedPackage);
            if (launch == null) {
                toast("Không tìm thấy màn hình mở cho app này.");
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            toast("Không mở được app server: " + e.getMessage());
        }
    }

    private void toggleKeeper() {
        boolean active = prefs().getBoolean(KEY_ACTIVE, false);
        if (active) {
            Intent stop = new Intent(this, ServerKeeperService.class);
            stop.setAction(ServerKeeperService.ACTION_STOP);
            startService(stop);
            prefs().edit().putBoolean(KEY_ACTIVE, false).apply();
            refreshStatus();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Bật chế độ giữ CPU thức?")
                .setMessage("Chế độ này giúp CPU không ngủ khi màn hình tắt, nhưng có thể làm hao pin và nóng máy. Hãy chỉ bật khi server đang chạy; nên cắm sạc và dừng chế độ khi không dùng.")
                .setNegativeButton("Để sau", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Bật chế độ", (dialog, which) -> {
                    Intent start = new Intent(this, ServerKeeperService.class);
                    start.setAction(ServerKeeperService.ACTION_START);
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(start);
                        else startService(start);
                        prefs().edit().putBoolean(KEY_ACTIVE, true).apply();
                        refreshStatus();
                    } catch (Exception e) {
                        toast("Không bật được dịch vụ nền: " + e.getMessage());
                    }
                }).show();
    }

    private void openSelectedAppSettings() {
        if (selectedPackage.isEmpty()) {
            toast("Chọn app server trước nhé.");
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + selectedPackage));
            startActivity(intent);
        } catch (Exception e) {
            toast("Không mở được cài đặt app.");
        }
    }

    private void openBatteryOptimizationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                toast("Không mở được cài đặt pin.");
            }
        }
    }

    private void refreshStatus() {
        if (stateTitle == null) return;
        boolean active = prefs().getBoolean(KEY_ACTIVE, false);
        if (active) {
            stateTitle.setText("ĐANG GIỮ CPU THỨC");
            stateTitle.setTextColor(green);
            stateDetails.setText("Dịch vụ nền đang bật. Hãy giữ app server chạy và kiểm tra cài đặt pin của HyperOS.");
            keeperButton.setText("TẮT CHẾ ĐỘ GIỮ CPU THỨC");
            keeperButton.setBackground(roundRect(Color.rgb(94, 43, 58), 14, 1, Color.rgb(150, 75, 94)));
            keeperButton.setTextColor(white);
        } else {
            stateTitle.setText("CHƯA BẬT CHẾ ĐỘ GIỮ NỀN");
            stateTitle.setTextColor(white);
            stateDetails.setText("Bật chế độ này khi server đang chạy. CPU sẽ được giữ thức trong lúc chế độ hoạt động.");
            keeperButton.setText("BẬT CHẾ ĐỘ GIỮ CPU THỨC");
            keeperButton.setBackground(roundRect(green, 14, 1, green));
            keeperButton.setTextColor(bg);
        }
    }

    private LinearLayout cardLayout(int color, int padding) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(padding), dp(padding), dp(padding), dp(padding));
        layout.setBackground(roundRect(color, 16, 0, color));
        return layout;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, int color, int textColor) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(textColor);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(52));
        button.setPadding(dp(12), dp(10), dp(12), dp(10));
        button.setBackground(roundRect(color, 14, 1, color));
        return button;
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams lpWrap(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private LinearLayout.LayoutParams lpMatch(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static class AppEntry {
        final String label;
        final String packageName;

        AppEntry(String label, String packageName) {
            this.label = label;
            this.packageName = packageName;
        }
    }
}
