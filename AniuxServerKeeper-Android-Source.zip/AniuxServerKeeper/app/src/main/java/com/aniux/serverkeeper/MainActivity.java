package com.aniux.serverkeeper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "keeper_prefs";
    private static final String KEY_PACKAGE = "server_package";
    private TextView selectedApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 31));
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));
        page.setBackgroundColor(Color.rgb(7, 17, 31));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("ANIUX SERVER KEEPER");
        title.setTextColor(Color.rgb(64, 190, 255));
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Giữ điện thoại thức khi chạy server trên Android");
        subtitle.setTextColor(Color.rgb(190, 207, 225));
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subtitleParams = params(-1, -2);
        subtitleParams.topMargin = dp(8);
        subtitleParams.bottomMargin = dp(22);
        page.addView(subtitle, subtitleParams);

        TextView status = new TextView(this);
        status.setText("●  CÁCH DÙNG");
        status.setTextColor(Color.rgb(99, 224, 180));
        status.setTextSize(15);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(status);

        TextView instructions = new TextView(this);
        instructions.setText("1. Bấm BẬT GIỮ THỨC.\n2. Chọn app dùng để chạy server.\n3. Để thông báo Keeper hiển thị khi đang chạy.\n4. Trong cài đặt pin, đặt app server và Keeper thành Không hạn chế nếu máy có tùy chọn này.");
        instructions.setTextColor(Color.rgb(210, 221, 235));
        instructions.setTextSize(14);
        instructions.setLineSpacing(dp(5), 1f);
        instructions.setPadding(dp(14), dp(14), dp(14), dp(14));
        instructions.setBackground(panelBackground());
        LinearLayout.LayoutParams infoParams = params(-1, -2);
        infoParams.topMargin = dp(10);
        infoParams.bottomMargin = dp(20);
        page.addView(instructions, infoParams);

        Button start = makeButton("BẬT GIỮ THỨC", true);
        start.setOnClickListener(v -> startKeeper());
        page.addView(start, buttonParams());

        Button stop = makeButton("TẮT GIỮ THỨC", false);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, KeeperService.class));
            Toast.makeText(this, "Đã gửi lệnh tắt Keeper", Toast.LENGTH_SHORT).show();
        });
        page.addView(stop, buttonParams());

        Button choose = makeButton("CHỌN / MỞ APP SERVER", false);
        choose.setOnClickListener(v -> showLauncherApps());
        page.addView(choose, buttonParams());

        selectedApp = new TextView(this);
        selectedApp.setTextColor(Color.rgb(190, 207, 225));
        selectedApp.setTextSize(13);
        selectedApp.setPadding(dp(2), dp(4), dp(2), dp(12));
        page.addView(selectedApp);
        updateSelectedApp();

        Button battery = makeButton("CÀI ĐẶT PIN CỦA APP SERVER", false);
        battery.setOnClickListener(v -> openSelectedAppSettings());
        page.addView(battery, buttonParams());

        Button keeperBattery = makeButton("CÀI ĐẶT PIN CỦA KEEPER", false);
        keeperBattery.setOnClickListener(v -> openKeeperBatterySettings());
        page.addView(keeperBattery, buttonParams());

        TextView warning = new TextView(this);
        warning.setText("LƯU Ý: Ứng dụng này chỉ giữ CPU thức và có thông báo nền. Nó không thể ngăn Android/HyperOS tự dừng, buộc dừng hoặc làm app server bị lỗi. Server vẫn cần app server đang chạy, mạng ổn định và điện thoại có đủ pin.");
        warning.setTextColor(Color.rgb(255, 202, 120));
        warning.setTextSize(13);
        warning.setPadding(dp(14), dp(14), dp(14), dp(14));
        warning.setBackground(panelBackground());
        LinearLayout.LayoutParams warningParams = params(-1, -2);
        warningParams.topMargin = dp(16);
        page.addView(warning, warningParams);

        setContentView(scroll);
    }

    private void startKeeper() {
        Intent service = new Intent(this, KeeperService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
        Toast.makeText(this, "Đã gửi lệnh bật Keeper. Kiểm tra thông báo.", Toast.LENGTH_LONG).show();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void showLauncherApps() {
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = getPackageManager().queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager())));
            }
        });
        List<ResolveInfo> filtered = new ArrayList<>();
        for (ResolveInfo app : apps) {
            if (!app.activityInfo.packageName.equals(getPackageName())) filtered.add(app);
        }
        if (filtered.isEmpty()) {
            Toast.makeText(this, "Không tìm thấy app có thể mở", Toast.LENGTH_LONG).show();
            return;
        }
        String[] labels = new String[filtered.size()];
        for (int i = 0; i < filtered.size(); i++) labels[i] = String.valueOf(filtered.get(i).loadLabel(getPackageManager()));
        new AlertDialog.Builder(this)
            .setTitle("Chọn app chạy server")
            .setItems(labels, (dialog, which) -> {
                ResolveInfo choice = filtered.get(which);
                String packageName = choice.activityInfo.packageName;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_PACKAGE, packageName).apply();
                updateSelectedApp();
                Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                if (launch != null) {
                    try { startActivity(launch); }
                    catch (Exception e) { Toast.makeText(this, "Không mở được app đã chọn", Toast.LENGTH_SHORT).show(); }
                }
            })
            .setNegativeButton("Đóng", null)
            .show();
    }

    private void updateSelectedApp() {
        if (selectedApp == null) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String pkg = prefs.getString(KEY_PACKAGE, null);
        if (pkg == null) {
            selectedApp.setText("App server đã chọn: Chưa chọn");
            return;
        }
        try {
            CharSequence label = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0));
            selectedApp.setText("App server đã chọn: " + label + "\nGói: " + pkg);
        } catch (Exception e) {
            selectedApp.setText("App server đã chọn: " + pkg);
        }
    }

    private void openSelectedAppSettings() {
        String pkg = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PACKAGE, null);
        if (pkg == null) {
            Toast.makeText(this, "Bạn hãy chọn app server trước", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Không mở được cài đặt app server", Toast.LENGTH_SHORT).show();
        }
    }

    private void openKeeperBatterySettings() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Hãy tìm Keeper trong cài đặt pin của máy", Toast.LENGTH_LONG).show(); }
        }
    }

    private Button makeButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(primary ? Color.rgb(5, 20, 35) : Color.rgb(221, 239, 255));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? Color.rgb(64, 190, 255) : Color.rgb(18, 36, 58));
        bg.setCornerRadius(dp(13));
        if (!primary) {
            bg.setStroke(dp(1), Color.rgb(46, 104, 148));
        }
        button.setBackground(bg);
        button.setPadding(dp(12), dp(9), dp(12), dp(9));
        return button;
    }

    private GradientDrawable panelBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(13, 27, 44));
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), Color.rgb(30, 64, 91));
        return bg;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = params(-1, -2);
        p.bottomMargin = dp(10);
        return p;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
