package com.aniux.serverkeeper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class StopKeeperReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.stopService(new Intent(context, KeeperService.class));
    }
}
