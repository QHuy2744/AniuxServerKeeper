# Aniux Server Keeper

An Android helper app that runs a foreground service and acquires a partial CPU wake lock while enabled. It can list installed launcher apps, open the selected server app, and open that app's Android App info settings.

## Build with GitHub Actions

1. Extract the ZIP.
2. Upload the project contents to the root of your GitHub repository (the root should contain `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `.github/`).
3. Open **Actions** and run **Build Aniux Server Keeper APK** (or push to `main`/`master`).
4. Open the completed workflow run, find **Artifacts**, and download `AniuxServerKeeper-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Limitations

- The foreground service and partial wake lock can increase battery use and heat.
- This app cannot prevent Android, HyperOS, or the target server app from force-stopping, crashing, or being killed by the operating system.
- To improve reliability, open the selected server app's App info and set its battery mode to Unrestricted/No restrictions if your phone offers that option. Also check the phone's background/autostart settings.
- Android may still limit services based on OS version and device policy. This is a sideload/debug build, not a Play Store release.
